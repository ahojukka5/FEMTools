# -*- coding: utf-8 -*-
"""Pintarakenteet, harjoitus 5, tehtävä 2, DKT versio"""

from __future__ import division
from teefem.ca import *

# Lähtötiedot

E = 100.0e9
nu = 0.3
q = 100.0e3
t = 10.0e-3

# Obsolete command
# DEBUT()

# Read mesh from file
MAIL = LIRE_MAILLAGE(FORMAT = 'MED')


# Modify mesh
#MAIL = DEFI_GROUP(
#    reuse = MAIL,
#    MAILLAGE = MAIL,
#    CREA_GROUP_NO = _F(TOUT_GROUP_MA='OUI'),
#)

# Create model
#MO = AFFE_MODELE(
#    MAILLAGE = MAIL,
#    AFFE = _F(
#        GROUP_MA = 'OM1',
#        PHENOMENE = 'MECANIQUE',
#        MODELISATION = 'DKT',
#    ),
#)

# Define material
#MAT = DEFI_MATERIAU(
#    ELAS = _F(
#        E = E, 
#        NU = nu,
#    ),
#)

# Assign material to model
#CHMAT = AFFE_MATERIAU(
#    MAILLAGE = MAIL,
#    AFFE = _F(GROUP_MA = 'OM1', MATER = MAT),
#)

# Define boundary condition
#LO = AFFE_CHAR_MECA(
#    MODELE = MO,
#    FORCE_COQUE = _F(
#        GROUP_MA = 'OM1',
#        PRES = q,
#    ),
#)

# Define boundary condition
#BC = AFFE_CHAR_MECA(
#    MODELE = MO,
#    DDL_IMPO = (
#        _F(GROUP_NO = ('GA1'), LIAISON = 'ENCASTRE'),
#    ),
#)

# Define properties of elements
#CAREL = AFFE_CARA_ELEM(
#    MODELE = MO,
#    COQUE = _F(GROUP_MA = 'OM1', EPAIS = t),
#)

# Solve static
#RESU = MECA_STATIQUE(
#    MODELE = MO, 
#    CHAM_MATER = CHMAT,
#    CARA_ELEM = CAREL,
#    EXCIT = (
#        _F(CHARGE = LO),
#        _F(CHARGE = BC),
#    ),
#)

# Postprocess results to file
#IMPR_RESU(
#    FORMAT = 'RESULTAT',
#    RESU = _F(RESULTAT = RESU, VALE_MAX = 'OUI', VALE_MIN = 'OUI'),
#)

# Obsolete command
# FIN()
