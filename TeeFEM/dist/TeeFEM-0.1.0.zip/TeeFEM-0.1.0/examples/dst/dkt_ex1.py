# -*- coding: utf-8 -*-
"""
Created on Sun Feb 12 16:47:02 2012
@author: Jukka Aho
"""

import teefem as tf
from teefem.models import dkt

meshfile = 'tria3.mail' # Linear triangle mesh file

t = 10e-3
F = 100e3
q = 100e3

mesh = tf.geom.Mesh(filename = meshfile)
mdl = dkt.DKT(mesh = mesh)
mat = tf.materials.ElasticMaterialModel(E = 210.0e9, nu = 0.3)
mesh.assign_material(mat)

mdl.assign_bc(elem_group = 'OM1', pressure = q)

# Define boundary condition
#LO = AFFE_CHAR_MECA(
#    MODELE = MO,
#    FORCE_COQUE = _F(
#        GROUP_MA = 'OM1',
#        PRES = q,
#    ),
#)

mdl.assign_bc(node_group = 'P1', fy = -F/t)
mdl.assign_bc(node_group = 'GA1', dx = 0, dy = 0)
mdl.static_solve()

#print mdl.group_no
#print dir(mdl.group_no)
P1 = iter(mdl.group_no['P1']).next()
print("DY: %0.14E"%(P1.fields['DEPL']['DY']))