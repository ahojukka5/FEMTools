# -*- coding: utf-8 -*-
"""
Created on Fri Mar 09 04:52:59 2012

@author: Jukka
"""

import teefem

n1 = teefem.geom.Node(x=0.0, y=0.0)
n2 = teefem.geom.Node(x=2.0, y=1.0)
n3 = teefem.geom.Node(x=0.5, y=2.0)
tr3 = teefem.geom.Tria3(name = 'tr3', nodes = (n1, n2, n3))

tr3.material = teefem.materials.ElasticMaterialModel(E = 210e9, nu = 0.3)
el3 = teefem.models.MECPTR3(shape = tr3)

print el3.material_matrix
print el3.kinematic_matrix(1.0/3.0,1.0/3.0)
print el3.stiffness_matrix

# el3.plot(filename = 'MECPTR3.png')