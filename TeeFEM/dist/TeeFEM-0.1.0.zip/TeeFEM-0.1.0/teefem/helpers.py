# -*- coding: utf-8 -*-
"""
Created on Sun Feb 12 16:11:41 2012

@author: Jukka Aho
"""

#####################################
### Helpers.py - HELPER FUNCTIONS ###
#####################################

