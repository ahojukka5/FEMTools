# -*- coding: utf-8 -*-
__version__ = '0.1.0'
__author__ = 'Jukka Aho'
__email__ = 'ahojukka5@gmail.com'