#!/usr/bin/env python
# -*- coding: utf-8 -*-
__doc__ = """ Pintarakenteet, harjoitustyö 2, DKT referenssiratkaisu """

from teefem import ca
import sys

std1 = ca.study(
    name = 'dst',
    description = 'DST elements',
    additionalfiles = (
        ca.caf(fname = 'tria3.med', type = 'med', opts = 'D', unite = 20),
        ca.caf(fname = 'tria3.mail', type = 'mail', opts = 'R', unite = 26),
    ),
)

def run(argv):
    studies = (std1,)
    ca.run(studies, argv)

if __name__ == '__main__': run(sys.argv[1:])
