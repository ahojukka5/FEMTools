# -*- coding: utf-8 -*-
"""
Created on Sun Mar 11 22:52:12 2012

@author: Jukka

Plottausfunktioita

"""

from __future__ import division
import matplotlib.tri as tri
import matplotlib.pylab as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

def plotwf3d(data):
    ''' Kolmioi pistejoukon (xi,yi) ja plottaa '''
    tr = tri.Triangulation(data[:,0], data[:,1])
    fig = plt.figure()
    ax = fig.gca(projection = '3d')
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('z')
    ax.grid()
#    ax.scatter(data[:,0],data[:,1],data[:,2])
    for edge in tr.edges:
        idx1 = edge[0]
        idx2 = edge[1]
        x1 = data[idx1,0]
        y1 = data[idx1,1]
        z1 = data[idx1,2]
        x2 = data[idx2,0]
        y2 = data[idx2,1]
        z2 = data[idx2,2]
        ax.plot([x1,x2],[y1,y2],[z1,z2], 'b')
    return fig

X = np.linspace(0,1,15)
Xran = range(len(X))
w = lambda k,e: 0*k*np.sin(e)
data = np.array([(X[i],X[j],w(X[i],X[j])) for j in Xran for i in Xran[0:len(X)-j]])
print data
tr = plotwf3d(data)
plt.show()