# Copyright (c) 2012 FILL IN

import unittest

import teefemlib as tf
from teefem.helpers import dist
from teefem.nets import Node

class TestTeefemlib(unittest.TestCase):
    def test_main(self):
        pass

if __name__ == '__main__':
    unittest.main()
