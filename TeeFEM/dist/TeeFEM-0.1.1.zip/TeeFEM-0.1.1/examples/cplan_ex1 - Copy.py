# -*- coding: utf-8 -*-
"""
Created on Sun Feb 12 16:47:02 2012
@author: Jukka Aho
"""

import teefem as tf
import numpy as np
#from teefem.models import c_plan

meshfile = teefem.os.path.join(teefem.datadir, 'tria3.mail') # Linear triangle mesh file

#meshfile = 'meshfiles/cplan_tria3.mail' # Linear triangle elements MECPTR3
meshfile = 'meshfiles/cplan_tria6.mail' # Quadratic triangle elements MECPTR6
#meshfile = 'meshfiles/cplan_quad4.mail' # Linear quadrangle elements MECPQU4
#meshfile = 'meshfiles/cplan_quad8.mail' # Quadratic quadrangle elements MECPQU8

t = 10e-3
F = 100e3
q = 100e3

mesh = None
    
with open(meshfile,'r') as fh:
    mesh = tf.geom.parsemail(fh)

# mesh = tf.geom.Mesh(filename = meshfile)

mat = tf.materials.Elastic(E = 210.0e9, nu = 0.3)
mesh.assign_material(mat)

mdl = c_plan.C_PLAN(mesh = mesh)
mdl.assign_bc(elem_group = 'GA2', pressure = q/t)
mdl.assign_bc(node_group = 'P1', fy = -F/t)
mdl.assign_bc(node_group = 'GA1', dx = 0, dy = 0)
import time
for i in range(1):
    t0 = time.clock()
    mdl.static_solve()
    t1 = time.clock()
    print("Solving KU=F system took {0} seconds".format(t1-t0))

#print mdl.group_no
#print dir(mdl.group_no)
P1 = iter(mdl.nset['P1']).next()
print("DY: %0.14E"%(P1.fields['DEPL']['DY']))

sf = 50

import matplotlib.pylab as plt

# Siirtymäkenttä solmupisteissä
plt.figure(1)
x = [n.x+n.fields['DEPL']['DX']*sf for n in mdl.nodes]
y = [n.y+n.fields['DEPL']['DY']*sf for n in mdl.nodes]
plt.scatter(x,y)

# Mises jännitys integroimispisteitä interpoloimalla
# http://www.scipy.org/Cookbook/Matplotlib/Gridding_irregularly_spaced_data
plt.figure(2)
from scipy.interpolate import griddata
x = []
y = []
vmis = []
for e in mdl.elset['OM1']:
    for ke in e.ipoints:
        x.append(e.geom.x(*ke))
        y.append(e.geom.y(*ke))
        vmis.append(e.vmis(*ke)/1e6)
# define grid.
xi = np.linspace(min(x),max(x),100)
yi = np.linspace(min(y),max(y),100)
# grid the data.
si = griddata((x, y), vmis, (xi[None,:], yi[:,None]), method='cubic')
# contour the gridded data, plotting dots at the randomly spaced data points.
CS = plt.contour(xi,yi,si,30,linewidths=0.5,colors='k')
CS = plt.contourf(xi,yi,si,30,cmap=plt.cm.jet)
plt.colorbar() # draw colorbar
# plot data points.
# plt.scatter(x,y,marker='o',c='b',s=5)
plt.xlim(min(x),max(x))
plt.ylim(min(y),max(y))
#plt.tight_layout()

plt.show()
